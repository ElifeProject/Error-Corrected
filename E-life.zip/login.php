<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title><?php echo isset($page_title) ? strip_tags($page_title) : "E-Life"; ?></title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>
<?php
include_once "config/core.php";

$page_title = "Login";
//include login cheker
$require_login =false;
//include_once "login_checker.php";
//default  to false
$access_denied=false;

//<!-- Post Content -->


//form
include_once "layout_header.php";
echo"<div class='col-md-8 col-sm-12'>";


    echo"<form action='" .htmlspecialchars($_SERVER["PHP_SELF"]) ."' method='post'>";
            echo"<div class='form-group'>";
                echo"<label for='name'><div class='font-clr'>Email:</div></label>";
                echo"<input type='text' class='form-control'  placeholder='Enter email' name='email' required autofocus>";
            echo"</div>";
            echo"<div class='form-group'>";
                echo"<label for='password'><div class='font-clr'>Password:</div></label>";
                echo"<input type='password' class='form-control'  placeholder='Enter Password' name='password' required>";
            echo"</div>";
            echo"<br>";
            echo"<button type='submit' class='btn btn-default' value='Log In'>Log In</button>";
            echo"</form>";
            echo"<br>";
            echo"<h4 class='font-clr'>Don't have an account yet. <a href='SignUp.php'><h4 class='font-clr'>Sign Up!</h4></a></h4>";
        echo"</div>";
    echo"</div>";
echo"</div>";
 ///form end

 ///footer
 include_once "layout_footer.php";  
?>
        